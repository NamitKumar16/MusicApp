// How async work
Future<int> cube(int num) {
  print("Ham first");
  return Future.value(num * num * num);
}

asyncTask() {
  print("I am the first line");
  Future.delayed(Duration(seconds: 5), () {
    print("5");
    Future.delayed(Duration(seconds: 4), () {
      print("4");
      Future.delayed(Duration(seconds: 3), () {
        print("3");
        Future.delayed(Duration(seconds: 2), () {
          print("2");
          Future.delayed(Duration(seconds: 1), () {
            print("1");
          });
        });
      });
    });
  });
  print("Last Line");
}

void main() {
  // asyncTask();
  Future<int> future = cube(3);
  future.then((value) => print(value)).catchError((err) => print("err"));
  print("Bye Bye");
}
