import 'package:audioplayers/audioplayers.dart';
import 'package:flutter/material.dart';
import 'package:music_app/models/song.dart';
import 'package:music_app/screens/utils/api_client.dart';

class ListOfSongs extends StatefulWidget {
  const ListOfSongs({Key? key}) : super(key: key);

  @override
  _ListOfSongsState createState() => _ListOfSongsState();
}

class _ListOfSongsState extends State<ListOfSongs> {
  AudioPlayer audioPlayer = AudioPlayer();
  List<Song> songs = [];
  dynamic error;
  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    ApiClient client = ApiClient();
    client.getSongs(getSongList, getSongError);
  }

  getSongList(List<Song> songs) {
    this.songs = songs;
    setState(() {});
  }

  getSongError(dynamic error) {
    this.error = error;
    setState(() {});
  }

  Center _showLoading() {
    return Center(child: CircularProgressIndicator());
  }

  ListView _printSong() {
    return ListView.builder(
      itemBuilder: (BuildContext ctx, int index) {
        return ListTile(
          leading: Image.network(songs[index].image),
          title: Text(songs[index].trackName),
          subtitle: Text(songs[index].artistName),
          trailing: IconButton(
            onPressed: () async {
              if (!songs[index].isPlaying) {
                await audioPlayer.play(songs[index].audio);

                setState(() {
                  songs[index].isPlaying = true;
                });
              } else {
                await audioPlayer.pause();

                setState(() {
                  songs[index].isPlaying = false;
                });
              }
            },
            icon: !songs[index].isPlaying
                ? const Icon(
                    Icons.play_arrow_rounded,
                    size: 30,
                    color: Colors.redAccent,
                  )
                : const Icon(
                    Icons.pause_rounded,
                    size: 30,
                    color: Colors.redAccent,
                  ),
          ),
        );
      },
      itemCount: songs.length,
    );
  }

  // Icon(Icons.play_arrow_rounded,size: 30, color: Colors.redAccent,)
  //  IconButton(
  // icon: toggle
  //     ? Icon(Icons.favorite_border)
  //     : Icon(
  //         Icons.favorite,
  //       ),
  //         onPressed: () {
  //           setState(() {
  //             // Here we changing the icon.
  //             toggle = !toggle;
  //           });
  //         }),
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Songs'),
      ),
      body:
          Container(child: (songs.length == 0) ? _showLoading() : _printSong()),
    );
  }
}
